import bluelake as bl
from bluelake import pause, confocal, fluidics, excitation_lasers, mirror1, microstage

from importlib import reload
#import dna_catcher
#reload(dna_catcher)

probeflowtime = 2
catchprobetime = 60


# functions =================
def timeprogression(time, numsteps):
    stepsize = round(time / numsteps, 2)
    for i in range(1, numsteps + 1):
        pause(stepsize)
        print(" " + str(round(i * stepsize * 100 / time)) + "% of time has elapsed (" + str(
            round(i * stepsize / 60, 1)) + " min)")


def setpressure(pres):
    pt = 0.1
    curpres = fluidics.pressure
    if curpres < pres:
        while fluidics.pressure < pres:
            fluidics.increase_pressure()
            pause(pt)  # important!
    else:
        while fluidics.pressure > pres:
            fluidics.decrease_pressure()
            pause(pt)  # important!


trap = mirror1


def catching_cycle():
    trap.move_to(waypoint="start")
    print("MOVE INTO PROBE REGION")
    microstage.move_to("J1", speed=0.2)
    microstage.move_to("Ch4", speed=0.2)

    print("REFRESH PROBES")
    fluidics.open(1, 2, 3, 4, 5, 6)
    timeprogression(probeflowtime, 5)
    fluidics.close(1, 2, 3, 4, 5, 6)

    print("HANG OUT FOR PROBING")
    timeprogression(catchprobetime, 5)

    print("MOVE MOVE INTO IMAGING REGION")

    setpressure(0)
    fluidics.open(1, 2, 3, 6)
    timeprogression(10, 10)
    fluidics.close(1, 2, 3, 6)
    setpressure(0)

    microstage.move_to("J1", speed=0.2)
    microstage.move_to("img", speed=0.2)
    pause(1)


def image_cycle():
    print("LASER ON")
    excitation_lasers.green = 12
    #bl.reset_force()
    trap.move_to(waypoint="catch dna")
    trap.move_to(waypoint="ssdna stretch low", speed=5)
    print("IMAGE START")
    confocal.start_scan("Rep kymo")
    pause(3)

    print("STRETCH START")
    ## change stretching rate at high force (>70 pN)

    #print("START 300 nm per s")
    #trap.move_to(waypoint="ssdna stretch low", speed=0.3)

    #print("START 100 nm per s")
    #trap.move_to(waypoint="ssdna stretch low", speed=0.3)

    #trap.move_to(waypoint="ssdna stretch very low", speed=0.1)
    print("START 20 nm per s")
    trap.move_to(waypoint="ssdna stretch", speed=0.02)
    pause(3)

    print("=== DONE! ===")
    confocal.abort_scan()
    excitation_lasers.green = 0


# main ===============
#dna_catcher.main()

#excitation_lasers.green = 15
#setpressure(0)
#catching_cycles()
image_cycle()

#microstage.move_to("J1", speed=0.25)


























